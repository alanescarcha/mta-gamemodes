
setMinuteDuration ( 30000 )

local time = getRealTime()
setTime (time.hour,time.minute)