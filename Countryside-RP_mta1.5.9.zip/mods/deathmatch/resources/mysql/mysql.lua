connection = dbConnect( "mysql", "dbname=NOMBRE_DB;host=HOST_DB", "USUARIO_DB", "CLAVE_DB", "share=0" )

function connect()
	return connection
end

addEventHandler('onResourceStop', resourceRoot,
    function ()
        if (isElement(connection)) then
            destroyElement(connection)
        end
    end
)

