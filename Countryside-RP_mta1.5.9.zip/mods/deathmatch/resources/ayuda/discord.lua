function discord( player )
outputChatBox("https://discord.com/invite/Ksc6h8ZYUZ")
end
addCommandHandler("discord", discord)


