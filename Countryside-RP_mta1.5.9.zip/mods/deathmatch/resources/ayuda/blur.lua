addEventHandler( "onClientResourceStart", resourceRoot,
	function()
		setBlurLevel ( 0 )
	end
)