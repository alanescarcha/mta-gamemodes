--[[
Copyright (c) 2010 MTA: Paradise
Copyright (c) 2020 DownTown RolePlay
Copyright (c) 2016 DownTown County Roleplay

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
]]

routes =
{
	{
		{ x = 2066.98, y = -72.34, z = 0.08, stop = true, hint = "Es sencillo, para en los puntos para tirar la red y pescar"},
		{ x = 1961.85, y = -62.33, z = 0.09, stop = true },
		{ x = 1799.47, y = -11.91, z = 0.09, stop = true },
		{ x = 1595.29, y = -51.56, z = 0.08, stop = true },
		{ x = 1519.98, y = -224.76, z = 0.09, stop = true },
		{ x = 1380.88, y = -252.83, z = 0.07, stop = true },
		{ x = 1578.33, y = -170.81, z = 0.08, stop = true },
		{ x = 1684.63, y = -15.03, z = 0.09, stop = true },
		{ x = 1941.74, y = -191.18, z = 0.08, stop = true },
		{ x = 2129.47, y = -219.75, z = 0.08, stop = true },
		{ x = 2171.27, y = -151.85, z = 0.06, stop = true }
	}
}




